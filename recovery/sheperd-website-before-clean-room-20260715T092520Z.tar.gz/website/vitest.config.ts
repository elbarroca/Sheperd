import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";

export default defineConfig({
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  test: {
    environment: "node",
    include: ["tests/{unit,content}/**/*.test.ts"],
    coverage: {
      reporter: ["text", "json-summary"],
    },
  },
});
